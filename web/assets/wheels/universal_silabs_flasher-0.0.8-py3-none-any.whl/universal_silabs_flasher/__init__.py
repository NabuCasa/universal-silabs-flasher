MAJOR_VERSION = 0
MINOR_VERSION = 0
PATCH_VERSION = 8

__short_version__ = f"{MAJOR_VERSION}.{MINOR_VERSION}"
__version__ = f"{__short_version__}.{PATCH_VERSION}"
